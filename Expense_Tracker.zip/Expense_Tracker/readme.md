.hero {
    padding: 25px;
    border-radius: 18px;
    margin-bottom: 25px;

    background: linear-gradient(
        135deg,
        #667eea,
        #764ba2
    );

    color: white;
}

.metric-card {
    padding: 20px;

    border-radius: 16px;

    background: white;

    box-shadow:
        0 5px 20px rgba(0,0,0,0.08);

    margin-bottom: 15px;

    transition: 0.3s;
}

.metric-card:hover {
    transform: translateY(-5px);
}

.metric-icon {
    font-size: 30px;
}

.metric-title {
    color: #777;
    font-size: 14px;
}

.metric-value {
    font-size: 24px;
    font-weight: bold;
}

.metric-subtitle {
    color: #999;
    font-size: 12px;
}

.budget-box {
    padding: 25px;

    border-radius: 18px;

    background: white;

    box-shadow:
        0 5px 20px rgba(0,0,0,0.08);
}