import sqlite3
from pathlib import Path
import pandas as pd

# Database file location
DB_PATH = Path(__file__).resolve().parent / "expenses.db"


def get_connection():
    """Create and return a SQLite database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create database tables if they do not already exist."""

    conn = get_connection()
    cursor = conn.cursor()

    # Expenses table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL CHECK(amount > 0),
            payment_method TEXT NOT NULL,
            description TEXT DEFAULT ''
        )
    """)

    # Budget table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS budgets (
            month TEXT PRIMARY KEY,
            amount REAL NOT NULL DEFAULT 0
        )
    """)

    conn.commit()
    conn.close()


def add_expense(
    expense_date,
    category,
    amount,
    payment_method,
    description
):
    """Add a new expense."""

    conn = get_connection()

    conn.execute("""
        INSERT INTO expenses
        (date, category, amount, payment_method, description)
        VALUES (?, ?, ?, ?, ?)
    """, (
        expense_date,
        category,
        float(amount),
        payment_method,
        description
    ))

    conn.commit()
    conn.close()


def get_expenses():
    """Return all expenses as a Pandas DataFrame."""

    conn = get_connection()

    df = pd.read_sql_query("""
        SELECT
            id AS ID,
            date AS Date,
            category AS Category,
            amount AS Amount,
            payment_method AS Payment_Method,
            description AS Description
        FROM expenses
        ORDER BY date DESC, id DESC
    """, conn)

    conn.close()

    return df


def update_expense(
    expense_id,
    expense_date,
    category,
    amount,
    payment_method,
    description
):
    """Update an existing expense."""

    conn = get_connection()

    conn.execute("""
        UPDATE expenses
        SET
            date = ?,
            category = ?,
            amount = ?,
            payment_method = ?,
            description = ?
        WHERE id = ?
    """, (
        expense_date,
        category,
        float(amount),
        payment_method,
        description,
        expense_id
    ))

    conn.commit()
    conn.close()


def delete_expense(expense_id):
    """Delete an expense."""

    conn = get_connection()

    conn.execute(
        "DELETE FROM expenses WHERE id = ?",
        (expense_id,)
    )

    conn.commit()
    conn.close()


def get_budget(month):
    """Get budget for a particular month."""

    conn = get_connection()

    row = conn.execute(
        "SELECT amount FROM budgets WHERE month = ?",
        (month,)
    ).fetchone()

    conn.close()

    if row:
        return float(row["amount"])

    return None


def set_budget(month, amount):
    """Save or update monthly budget."""

    conn = get_connection()

    conn.execute("""
        INSERT INTO budgets (month, amount)
        VALUES (?, ?)
        ON CONFLICT(month)
        DO UPDATE SET amount = excluded.amount
    """, (
        month,
        float(amount)
    ))

    conn.commit()
    conn.close()


def seed_sample_data():
    """Insert sample data if database is empty."""

    conn = get_connection()

    count = conn.execute(
        "SELECT COUNT(*) AS count FROM expenses"
    ).fetchone()["count"]

    conn.close()

    if count > 0:
        return

    sample_data = [
        ("2026-08-01", "Food", 320, "UPI",
         "Breakfast and lunch"),

        ("2026-08-02", "Travel", 180, "Cash",
         "Bus and auto fare"),

        ("2026-08-03", "Shopping", 1250, "Card",
         "Clothes"),

        ("2026-08-04", "Bills", 850, "UPI",
         "Internet bill"),

        ("2026-08-05", "Education", 600, "UPI",
         "Online course"),

        ("2026-08-05", "Entertainment", 300, "Card",
         "Movie"),

        ("2026-08-06", "Food", 450, "UPI",
         "Dinner"),

        ("2026-07-05", "Health", 900, "Card",
         "Medicines"),

        ("2026-07-12", "Travel", 700, "Cash",
         "Weekend trip"),

        ("2026-07-18", "Shopping", 1600, "Card",
         "Shoes"),

        ("2026-07-22", "Bills", 1200, "UPI",
         "Electricity bill"),

        ("2026-06-08", "Food", 500, "Cash",
         "Groceries"),

        ("2026-06-14", "Education", 1000, "UPI",
         "Books"),

        ("2026-06-20", "Entertainment", 450, "Card",
         "Streaming subscription")
    ]

    conn = get_connection()

    conn.executemany("""
        INSERT INTO expenses
        (date, category, amount, payment_method, description)
        VALUES (?, ?, ?, ?, ?)
    """, sample_data)

    conn.execute("""
        INSERT OR REPLACE INTO budgets
        (month, amount)
        VALUES (?, ?)
    """, ("2026-08", 5000))

    conn.commit()
    conn.close()


if __name__ == "__main__":

    init_db()
    seed_sample_data()

    print("Database created successfully!")
    print(f"Database location: {DB_PATH}")