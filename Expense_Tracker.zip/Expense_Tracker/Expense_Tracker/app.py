import streamlit as st
import pandas as pd
import plotly.express as px

from datetime import date, datetime

from database import (
    init_db,
    add_expense,
    get_expenses,
    update_expense,
    delete_expense,
    get_budget,
    set_budget,
    seed_sample_data
)


# =========================================================
# PAGE CONFIGURATION
# =========================================================

st.set_page_config(
    page_title="Personal Expense Tracker",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)


# =========================================================
# INITIALIZE DATABASE
# =========================================================

init_db()


# =========================================================
# CONSTANTS
# =========================================================

CATEGORIES = [
    "Food",
    "Travel",
    "Shopping",
    "Bills",
    "Education",
    "Health",
    "Entertainment",
    "Others"
]

PAYMENT_METHODS = [
    "Cash",
    "UPI",
    "Card"
]


# =========================================================
# CUSTOM CSS
# =========================================================

st.markdown("""
<style>

.main {
    background-color: #f5f7fb;
}

.hero {
    padding: 25px;
    border-radius: 18px;
    margin-bottom: 25px;

    background: linear-gradient(
        135deg,
        #667eea,
        #764ba2
    );

    color: white;
}

.hero h1 {
    margin-bottom: 5px;
}

.metric-card {
    padding: 20px;

    border-radius: 16px;

    background: white;

    box-shadow:
        0 5px 20px rgba(0,0,0,0.08);

    margin-bottom: 15px;

    transition: 0.3s;
}

.metric-card:hover {
    transform: translateY(-5px);
}

.metric-icon {
    font-size: 30px;
}

.metric-title {
    color: #777;
    font-size: 14px;
}

.metric-value {
    font-size: 24px;
    font-weight: bold;
}

.metric-subtitle {
    color: #999;
    font-size: 12px;
}

.budget-box {
    padding: 25px;

    border-radius: 18px;

    background: white;

    box-shadow:
        0 5px 20px rgba(0,0,0,0.08);
}

</style>
""", unsafe_allow_html=True)


# =========================================================
# HELPER FUNCTIONS
# =========================================================

def money(value):

    return f"₹{value:,.2f}"


def metric_card(
    title,
    value,
    icon,
    subtitle
):

    st.markdown(
        f"""
        <div class="metric-card">

            <div class="metric-icon">
                {icon}
            </div>

            <div class="metric-title">
                {title}
            </div>

            <div class="metric-value">
                {value}
            </div>

            <div class="metric-subtitle">
                {subtitle}
            </div>

        </div>
        """,
        unsafe_allow_html=True
    )


# =========================================================
# SIDEBAR
# =========================================================

st.sidebar.title("💰 Expense Tracker")

st.sidebar.caption(
    "Personal Finance Dashboard"
)


page = st.sidebar.radio(
    "Navigation",
    [
        "📊 Dashboard",
        "➕ Add Expense",
        "✏️ Manage Expenses",
        "🎯 Budget",
        "📥 Reports"
    ]
)


st.sidebar.divider()


# Theme

theme = st.sidebar.selectbox(
    "🎨 Theme",
    ["Light", "Dark"]
)


if theme == "Dark":

    st.markdown("""
    <style>

    .stApp {
        background-color: #0e1117;
        color: white;
    }

    [data-testid="stSidebar"] {
        background-color: #151a21;
    }

    .metric-card,
    .budget-box {
        background-color: #171d26;
        color: white;
    }

    </style>
    """, unsafe_allow_html=True)


# Sample data

if st.sidebar.button(
    "🌱 Load Sample Data",
    use_container_width=True
):

    seed_sample_data()

    st.sidebar.success(
        "Sample data loaded!"
    )

    st.rerun()


st.sidebar.divider()

st.sidebar.info(
    "SQLite database is used for permanent storage."
)


# =========================================================
# DASHBOARD
# =========================================================

if page == "📊 Dashboard":

    st.markdown(
        """
        <div class="hero">

            <h1>
                Personal Expense Tracker
            </h1>

            <p>
                Track spending, understand habits,
                and stay within your budget.
            </p>

        </div>
        """,
        unsafe_allow_html=True
    )


    df = get_expenses()


    if df.empty:

        st.info(
            "No expenses found. "
            "Add an expense or load sample data."
        )

        st.stop()


    df["Date"] = pd.to_datetime(
        df["Date"]
    ).dt.date


    # =====================================================
    # FILTERS
    # =====================================================

    st.subheader("🔎 Filters")


    col1, col2, col3, col4 = st.columns(4)


    with col1:

        start_date = st.date_input(
            "From",
            df["Date"].min()
        )


    with col2:

        end_date = st.date_input(
            "To",
            df["Date"].max()
        )


    with col3:

        category_filter = st.selectbox(
            "Category",
            ["All"] + CATEGORIES
        )


    with col4:

        months = sorted(
            df["Date"]
            .apply(
                lambda x:
                x.strftime("%Y-%m")
            )
            .unique(),
            reverse=True
        )

        month_filter = st.selectbox(
            "Month",
            ["All"] + months
        )


    search = st.text_input(
        "🔍 Search",
        placeholder=
        "Search description, category or payment method..."
    )


    # =====================================================
    # APPLY FILTERS
    # =====================================================

    filtered = df[
        (df["Date"] >= start_date) &
        (df["Date"] <= end_date)
    ]


    if category_filter != "All":

        filtered = filtered[
            filtered["Category"] ==
            category_filter
        ]


    if month_filter != "All":

        filtered = filtered[
            filtered["Date"]
            .apply(
                lambda x:
                x.strftime("%Y-%m")
            )
            == month_filter
        ]


    if search.strip():

        search_text = search.lower()

        filtered = filtered[
            filtered["Description"]
            .fillna("")
            .str.lower()
            .str.contains(
                search_text,
                regex=False
            )
            |
            filtered["Category"]
            .str.lower()
            .str.contains(
                search_text,
                regex=False
            )
            |
            filtered["Payment_Method"]
            .str.lower()
            .str.contains(
                search_text,
                regex=False
            )
        ]


    # =====================================================
    # KPI CALCULATIONS
    # =====================================================

    total_expenses = filtered["Amount"].sum()


    today_expenses = filtered.loc[
        filtered["Date"] == date.today(),
        "Amount"
    ].sum()


    current_month = (
        pd.Timestamp.today()
        .to_period("M")
    )


    monthly_expenses = filtered.loc[
        pd.to_datetime(
            filtered["Date"]
        ).dt.to_period("M")
        == current_month,
        "Amount"
    ].sum()


    average_expense = (
        filtered["Amount"].mean()
        if not filtered.empty
        else 0
    )


    budget = get_budget(
        date.today().strftime("%Y-%m")
    )


    budget = budget or 0


    remaining_budget = (
        budget - monthly_expenses
    )


    # =====================================================
    # KPI CARDS
    # =====================================================

    c1, c2, c3, c4, c5 = st.columns(5)


    with c1:

        metric_card(
            "Total Expenses",
            money(total_expenses),
            "💸",
            f"{len(filtered)} records"
        )


    with c2:

        metric_card(
            "This Month",
            money(monthly_expenses),
            "📅",
            "Current month"
        )


    with c3:

        metric_card(
            "Today",
            money(today_expenses),
            "☀️",
            date.today().strftime(
                "%d %b %Y"
            )
        )


    with c4:

        metric_card(
            "Average Expense",
            money(average_expense),
            "📈",
            "Per transaction"
        )


    with c5:

        metric_card(
            "Budget Left",
            money(remaining_budget),
            "🎯",
            "Current month"
        )


    # =====================================================
    # BUDGET WARNING
    # =====================================================

    if budget > 0:

        progress = min(
            monthly_expenses / budget,
            1
        )


        st.progress(progress)


        if monthly_expenses > budget:

            st.error(
                "🚨 Budget exceeded by "
                + money(
                    monthly_expenses -
                    budget
                )
            )


        elif monthly_expenses >= budget * 0.8:

            st.warning(
                "⚠️ You have used "
                + f"{progress:.0%}"
                + " of your monthly budget."
            )


        else:

            st.success(
                "✅ Spending is within budget."
            )


    if filtered.empty:

        st.warning(
            "No records match the selected filters."
        )

        st.stop()


    # =====================================================
    # CHART 1 - CATEGORY PIE
    # =====================================================

    col1, col2 = st.columns(2)


    with col1:

        category_data = (
            filtered
            .groupby(
                "Category",
                as_index=False
            )["Amount"]
            .sum()
        )


        fig = px.pie(
            category_data,
            names="Category",
            values="Amount",
            title="🥧 Category-wise Expenses",
            hole=0.35
        )


        st.plotly_chart(
            fig,
            use_container_width=True
        )


    # =====================================================
    # CHART 2 - PAYMENT DONUT
    # =====================================================

    with col2:

        payment_data = (
            filtered
            .groupby(
                "Payment_Method",
                as_index=False
            )["Amount"]
            .sum()
        )


        fig = px.pie(
            payment_data,
            names="Payment_Method",
            values="Amount",
            title="🍩 Payment Method Distribution",
            hole=0.6
        )


        st.plotly_chart(
            fig,
            use_container_width=True
        )


    # =====================================================
    # CHART 3 - MONTHLY BAR
    # =====================================================

    col3, col4 = st.columns(2)


    with col3:

        monthly_data = filtered.copy()


        monthly_data["Month"] = (
            pd.to_datetime(
                monthly_data["Date"]
            )
            .dt.to_period("M")
            .astype(str)
        )


        monthly_data = (
            monthly_data
            .groupby(
                "Month",
                as_index=False
            )["Amount"]
            .sum()
        )


        fig = px.bar(
            monthly_data,
            x="Month",
            y="Amount",
            title="📊 Monthly Expenses"
        )


        st.plotly_chart(
            fig,
            use_container_width=True
        )


    # =====================================================
    # CHART 4 - DAILY LINE
    # =====================================================

    with col4:

        daily_data = (
            filtered
            .groupby(
                "Date",
                as_index=False
            )["Amount"]
            .sum()
        )


        daily_data["Date"] = pd.to_datetime(
            daily_data["Date"]
        )


        fig = px.line(
            daily_data,
            x="Date",
            y="Amount",
            title="📈 Daily Expense Trend",
            markers=True
        )


        st.plotly_chart(
            fig,
            use_container_width=True
        )


    # =====================================================
    # RECENT EXPENSES
    # =====================================================

    st.subheader("🧾 Recent Expenses")


    recent = filtered.head(10).copy()


    recent["Date"] = pd.to_datetime(
        recent["Date"]
    ).dt.strftime("%d-%m-%Y")


    recent["Amount"] = recent[
        "Amount"
    ].apply(money)


    recent = recent[
        [
            "Date",
            "Category",
            "Amount",
            "Payment_Method",
            "Description"
        ]
    ]


    recent.columns = [
        "Date",
        "Category",
        "Amount",
        "Payment Method",
        "Description"
    ]


    st.dataframe(
        recent,
        use_container_width=True,
        hide_index=True
    )


# =========================================================
# ADD EXPENSE
# =========================================================

elif page == "➕ Add Expense":

    st.title("➕ Add New Expense")

    st.write(
        "Enter the details of your expense."
    )


    with st.form(
        "add_expense_form",
        clear_on_submit=True
    ):

        col1, col2 = st.columns(2)


        with col1:

            expense_date = st.date_input(
                "Date",
                date.today()
            )


            category = st.selectbox(
                "Category",
                CATEGORIES
            )


            amount = st.number_input(
                "Amount (₹)",
                min_value=0.01,
                step=10.0
            )


        with col2:

            payment_method = st.selectbox(
                "Payment Method",
                PAYMENT_METHODS
            )


            description = st.text_input(
                "Description"
            )


        submit = st.form_submit_button(
            "💾 Save Expense",
            use_container_width=True
        )


    if submit:

        add_expense(
            expense_date.isoformat(),
            category,
            amount,
            payment_method,
            description
        )


        st.success(
            "✅ Expense added successfully!"
        )


        st.balloons()


# =========================================================
# MANAGE EXPENSES
# =========================================================

elif page == "✏️ Manage Expenses":

    st.title("✏️ Manage Expenses")


    df = get_expenses()


    if df.empty:

        st.info(
            "No expenses available."
        )

        st.stop()


    df["Date"] = pd.to_datetime(
        df["Date"]
    ).dt.date


    selected_id = st.selectbox(
        "Select Expense",
        df["ID"].tolist()
    )


    row = df[
        df["ID"] == selected_id
    ].iloc[0]


    tab1, tab2 = st.tabs(
        [
            "✏️ Edit",
            "🗑️ Delete"
        ]
    )


    # -----------------------------------------------------
    # EDIT
    # -----------------------------------------------------

    with tab1:

        with st.form("edit_form"):

            col1, col2 = st.columns(2)


            with col1:

                edit_date = st.date_input(
                    "Date",
                    row["Date"]
                )


                edit_category = st.selectbox(
                    "Category",
                    CATEGORIES,
                    index=CATEGORIES.index(
                        row["Category"]
                    )
                )


                edit_amount = st.number_input(
                    "Amount (₹)",
                    min_value=0.01,
                    value=float(
                        row["Amount"]
                    ),
                    step=10.0
                )


            with col2:

                edit_payment = st.selectbox(
                    "Payment Method",
                    PAYMENT_METHODS,
                    index=PAYMENT_METHODS.index(
                        row["Payment_Method"]
                    )
                )


                edit_description = st.text_input(
                    "Description",
                    value=row["Description"]
                )


            update = st.form_submit_button(
                "💾 Update Expense",
                use_container_width=True
            )


        if update:

            update_expense(
                selected_id,
                edit_date.isoformat(),
                edit_category,
                edit_amount,
                edit_payment,
                edit_description
            )


            st.success(
                "Expense updated successfully!"
            )


            st.rerun()


    # -----------------------------------------------------
    # DELETE
    # -----------------------------------------------------

    with tab2:

        st.warning(
            "Deleting this expense cannot be undone."
        )


        if st.button(
            "🗑️ Delete Expense",
            type="primary"
        ):

            delete_expense(
                selected_id
            )


            st.success(
                "Expense deleted successfully!"
            )


            st.rerun()


    # Display table

    st.subheader(
        "All Expenses"
    )


    display_df = df.copy()


    display_df["Amount"] = (
        display_df["Amount"]
        .apply(money)
    )


    st.dataframe(
        display_df,
        use_container_width=True,
        hide_index=True
    )


# =========================================================
# BUDGET
# =========================================================

elif page == "🎯 Budget":

    st.title("🎯 Monthly Budget")


    current_month = (
        date.today()
        .strftime("%Y-%m")
    )


    month = st.text_input(
        "Month (YYYY-MM)",
        current_month
    )


    current_budget = (
        get_budget(month)
        or 0
    )


    budget_amount = st.number_input(
        "Monthly Budget (₹)",
        min_value=0.0,
        value=float(
            current_budget
        ),
        step=500.0
    )


    if st.button(
        "💾 Save Budget",
        use_container_width=True
    ):

        try:

            datetime.strptime(
                month,
                "%Y-%m"
            )


            set_budget(
                month,
                budget_amount
            )


            st.success(
                "Budget saved successfully!"
            )


        except ValueError:

            st.error(
                "Use YYYY-MM format."
            )


    # Spending calculation

    df = get_expenses()


    if not df.empty:

        df["Date"] = pd.to_datetime(
            df["Date"]
        )


        month_spending = df.loc[
            df["Date"]
            .dt.to_period("M")
            .astype(str)
            == month,
            "Amount"
        ].sum()


    else:

        month_spending = 0


    st.divider()


    col1, col2, col3 = st.columns(3)


    with col1:

        st.metric(
            "Budget",
            money(budget_amount)
        )


    with col2:

        st.metric(
            "Spent",
            money(month_spending)
        )


    with col3:

        st.metric(
            "Remaining",
            money(
                budget_amount -
                month_spending
            )
        )


    if budget_amount > 0:

        progress = min(
            month_spending /
            budget_amount,
            1
        )


        st.progress(
            progress
        )


        if month_spending > budget_amount:

            st.error(
                "🚨 Budget exceeded!"
            )

        elif month_spending >= budget_amount * 0.8:

            st.warning(
                "⚠️ You are close to your budget."
            )

        else:

            st.success(
                "✅ Spending is within budget."
            )


# =========================================================
# REPORTS
# =========================================================

elif page == "📥 Reports":

    st.title("📥 Expense Reports")


    df = get_expenses()


    if df.empty:

        st.info(
            "No data available."
        )

        st.stop()


    df["Date"] = pd.to_datetime(
        df["Date"]
    ).dt.date


    col1, col2, col3 = st.columns(3)


    with col1:

        report_start = st.date_input(
            "From",
            df["Date"].min()
        )


    with col2:

        report_end = st.date_input(
            "To",
            df["Date"].max()
        )


    with col3:

        report_category = st.selectbox(
            "Category",
            ["All"] + CATEGORIES
        )


    report_df = df[
        (df["Date"] >= report_start) &
        (df["Date"] <= report_end)
    ].copy()


    if report_category != "All":

        report_df = report_df[
            report_df["Category"]
            == report_category
        ]


    st.metric(
        "Report Total",
        money(
            report_df["Amount"].sum()
        )
    )


    st.dataframe(
        report_df,
        use_container_width=True,
        hide_index=True
    )


    csv_data = report_df.to_csv(
        index=False
    ).encode("utf-8")


    st.download_button(
        "⬇️ Download CSV Report",
        data=csv_data,
        file_name="expense_report.csv",
        mime="text/csv",
        use_container_width=True
    )