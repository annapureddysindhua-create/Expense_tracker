# 💰 Personal Expense Tracker with Data Visualization

A modern full-stack web application for managing personal expenses, tracking monthly budgets, and visualizing spending patterns through interactive charts.

---

## 📌 Project Overview

The Personal Expense Tracker is a full-stack expense management application developed using React, Python Flask, and SQLite.

The application allows users to:

- Add new expenses
- Edit existing expenses
- Delete expenses
- Search expenses
- Filter expenses
- Set monthly budgets
- Monitor budget usage
- View spending statistics
- Visualize expenses using interactive charts
- Download expense reports as CSV
- Switch between Dark and Light modes

The application provides a simple and professional dashboard that helps users understand their spending habits.

---

# 🛠️ Technologies Used

## Frontend

- React.js
- Vite
- Recharts
- Lucide React
- HTML
- CSS
- JavaScript

## Backend

- Python
- Flask
- Flask-CORS
- REST API

## Database

- SQLite

---

# 📁 Project Structure

```text
Expense_Tracker_Full_Stack/
│
├── README.md
│
├── backend/
│   ├── app.py
│   ├── database.py
│   ├── requirements.txt
│   └── expenses.db
│
└── frontend/
    ├── package.json
    ├── vite.config.js
    ├── index.html
    │
    └── src/
        ├── App.jsx
        ├── main.jsx
        └── styles.css